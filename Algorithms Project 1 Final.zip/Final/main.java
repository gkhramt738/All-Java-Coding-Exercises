//Author: Matt Costa

import java.util.Scanner;

public class main {
	public static void main(String[]args){
		int size;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter size of arrays");
		size = input.nextInt();


		//Define and initialize arrays A B
		int[][] A = new int[size][size];
		int[][] B = new int[size][size];
		int[][] C = new int[size][size];
		int[] D = new int [1]; // for testing sum method
		D[0] = 1; // assign value
		/**********Accuracy Testing********
	    int[][] A = new int[2][2];
			A[0][0] = 2;
			A[0][1] = 3;
			A[1][0] = 4;
			A[1][1] = 1;
		int[][] B = new int[2][2];
			B[0][0] = 5;
			B[0][1] = 7;
			B[1][0] = 6;
			B[1][1] = 8;
	    matrixmult(2, A, B, C); //given test arrays A and B, provides output 28, 38, 26, 36 consistent with the example from the textbook
		scalarmatmult(2, A, 2, C); //given test array A, provides output 4 6 8 2 consistent with result from https://onlinemschool.com/math/assistance/matrix/multiply1/
			************Accuracy Testing******/



		//randomly fill arrays A B
		randomFill(A);
		randomFill(B);
		//Run algorithms (UNCOMMENT INDEPENDENTLY TO RUN ALGORITHMS)
	//  sum(1, D);
	//	matrixmult(2, A, B, C);
	//	scalarmatmult(2, A, 2, C);

	/********	Future selection implementation *********
	   System.out.println("Select an array: A or B");
		if (input.next() != "A" || input.next() != "B")
			System.out.println("Error: Invalid Input");
		else if(input.next() == "A"){
			System.out.println("What operation would you like to perform?/n"
					+ "1. Multiply array by scalar/n"
					+ "2. Mutiply array by other array/n"
					+ "3. Sum array elements");
					switch(input.nextInt()){
					case 1: scalarmatmult(A);
					}*/

	}
//Fill array with random numbers 0 - 100
static void randomFill(int[][] A){
		for(int i=0;i<A.length;i++){
			for(int j=0; j<A[i].length;j++){
				A[i][j] = (int)(100* Math.random());
			}

		}
	}
//Algorithm 1.2 - Add Array Members
 static int sum(int n, int S[]){
	 	long currentTime = System.nanoTime(); //define algo start time\
		System.out.println("Current time: " + currentTime);
		int result = 0;
		for(int i=0; i<n;i++){
			result = result + S[i];
		}
		long endTime = System.nanoTime(); //define algo end time
		System.out.println("End time: " + endTime);
		long totalTime = endTime - currentTime; //calculate total algo runtime
		System.out.println("Algorithm sum runtime: " + (totalTime));
		return result;
	}
 //Scalar Matrix Multiplication
 static void scalarmatmult(int n, int[][] A, int b, int C[][]){
   	 long currentTime = System.nanoTime();	//define algo start time
	 System.out.println("Current time: " + currentTime);	
	 for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				C[i][j] = A[i][j] * b;
			}
		}
		long endTime = System.nanoTime(); //define algo end time
		System.out.println("End time: " + endTime);
		long totalTime = endTime - currentTime; //calculate total algo runtime
		System.out.println("Algorithm scalarmatult runtime: " + (totalTime));
	}
//Algorithm 1.4 - Matrix Multiplication
static void matrixmult(int n, int A[][], int B[][], int[][] C){
	long currentTime = System.nanoTime();	//define algo start time
	System.out.println("Current time: " + currentTime);
	for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				C[i][j]= 0;
				for(int k=0;k<n;k++){
					C[i][j] =C[i][j] + A[i][k] * B[k][j];

				}
			}
		}
		long endTime = System.nanoTime(); //define algo end time
		System.out.println("End time: " + endTime);
		long totalTime = endTime - currentTime; //calculate total algo runtime
		System.out.println("Algorithm matrixmult runtime: " + (totalTime));
	}

}
