#Author: George Khramtchenko
#Author: Matt Costa
import math
import random
import time

class main :
    @staticmethod
    def main(args) :    
        
        size = int(input("Enter the size of arrays:")) # Takes size of input from user
        
        matrix = []
        
        # --> I am having trouble initializing the arrays below using user input <--
        # This is because I do not understand how to define 2D arrays in Python and initislize
        # them with user input, and I have tried searchi9ng online but still just cannot get this part done.
        
        # #  Define and initialize arrays A, B, C
        A = [[0] * (size) for x in range(size)]
        B = [[0] * (size) for x in range(size)]
        C = [[0] * (size) for x in range(size)]
        D = [0] * (1)
        
        # A 2D example (halfway down the page (Code #2):
        #https://www.geeksforgeeks.org/take-matrix-input-from-user-in-python/
        
        #  for testing sum method
        D[0] = 1 #  assign value

        # *********
        # 		 * Accuracy Testing******** int[][] A = new int[2][2]; A[0][0] = 2; A[0][1] = 3;
        # 		 * A[1][0] = 4; A[1][1] = 1; int[][] B = new int[2][2]; B[0][0] = 5; B[0][1] =
        # 		 * 7; B[1][0] = 6; B[1][1] = 8; matrixmult(2, A, B, C); //given test arrays A
        # 		 * and B, provides output 28, 38, 26, 36 consistent with the example from the
        # 		 * textbook scalarmatmult(2, A, 2, C); //given test array A, provides output 4 6
        # 		 * 8 2 consistent with result from
        # 		 * https://onlinemschool.com/math/assistance/matrix/multiply1/ Accuracy Testing
        # 		 *****
        
        # *** --> ERRORS HERE <-- I get an attribute error, where "type object 'main' has no attribute
        # 'randomFill' ***
        # # Randomly fill arrays A, B
        
        # --> ERRORS HERE <-- I get another attribute error, where "type object 'main' has no attribute
        # 'sum', 'matrixmult' and 'scalarmatmult' ***
        # # Test algorithm runtimes
        # Fill array with random numbers 0 - 100
     #   @staticmethod
        def randomFill(A) :
            i = 0
            while (i < len(A)) :
                j = 0
                while (j < len(A[i])) :
                    A[i][j] = int((100 * random.randint(0, 100)))
                    j += 1
                i += 1
    
        # Algorithm 1.2 - Add Array Members
       # @staticmethod
        def  sum(n, S) :
            time_init = time.time_ns()
            print(str(time_init))
            #  define algo start time
            result = 0
            i = 0
            while (i < n) :
                result = result + S[i]
                i += 1
            time_end = time.time_ns()
            print(str(time_end))
            #  define algo end time
            time_final = time_end - time_init
            #  calculate total algo runtime
            print("Algorithm sum runtime: " + str((time_final)))
            return result
    
        #  Scalar Matrix Multiplication
        #@staticmethod
        def scalarmatmult(n, A, b, C) :
            time_init = time.time_ns()
            print(str(time_init))
            #  define algo start time
            i = 0
            while (i < n) :
                j = 0
                while (j < n) :
                    C[i][j] = A[i][j] * b
                    j += 1
                i += 1
            time_end = time.time_ns()
            print(str(time_end))
            #  define algo end time
            time_final = time_end - time_init
            #  calculate total algo runtime
            print("Algorithm scalarmatult runtime: " + str((time_final)))
    
        # Algorithm 1.4 - Matrix Multiplication
        def matrixmult(n, A, B, C) :
            time_init = time.time_ns()
            print(str(time_init))
            #  define algo start time
            i = 0
            while (i < n) :
                j = 0
                while (j < n) :
                    C[i][j] = 0
                    k = 0
                    while (k < n) :
                        C[i][j] = C[i][j] + A[i][k] * B[k][j]
                        k += 1
                    j += 1
                i += 1
            time_end = time.time_ns()
            print(str(time_end))
            #  define algo end time
            time_final = time_end - time_init
            #  calculate total algo runtime
            print("Algorithm matrixmult runtime: " + str((time_final)))
        randomFill(A)
        randomFill(B)
        #Run algorithms (UNCOMMENT INDEPENDENTLY TO RUN ALGORITHMS)
        #sum(1, D)
        #matrixmult(2, A, B, C)
        #scalarmatmult(2, A, 2, C)
            
if __name__=="__main__":
    main.main([])
