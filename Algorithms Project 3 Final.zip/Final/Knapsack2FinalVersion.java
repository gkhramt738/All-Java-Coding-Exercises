
/***************************************************************************/
/*                                                                    	   */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	      	   */
/*	   Assignment/Program: Project 3/Knapsack2FinalVersion			  	   */
/*	   Description: Solve the knapsack 0-1 problem using algorithm 6.1	   */
/*	   Author: Sarita Poudyal Bhandari								  	   */
/* 	   Modified: 05/17/2022	 	                                      	   */
/*                                                              	  	   */
/***************************************************************************/

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Knapsack2FinalVersion {

	static int[] p;
	static int[] w;
	static int W;
	static int n = 4;
	static int maxprofit, count;
	static List<Integer> includedLevels;

	/*
	 * Algorithm 6.1 - The Breadth-First Search with Branch-and-Bound Pruning
	 * Algorithm for the 0-1 Knapsack problem
	 */

	public static void knapsack2() {

		Queue<Node> queue = new LinkedList<>(); // Initialize queue empty.
		Node v1 = new Node();
		queue.clear();

		v1.level = -1; // Initialize v1 to be the root.
		v1.setProfit(0);
		v1.setWeight(0);

		maxprofit = 0;
		queue.add(v1);

		while (!queue.isEmpty()) {
			v1 = queue.remove();
			count++;

			Node u1 = new Node();
			u1.level = v1.level + 1;
			u1.weight = v1.weight + w[u1.level]; // Set u1 to a child of v
			u1.profit = v1.profit + p[u1.level]; // Set u1 to the child that includes the
													// next item.
			u1.setIncludedLevels(v1.getIncludedLevels());
			u1.appendLevel(u1.level);

			if (u1.weight <= W && u1.profit > maxprofit) {
				maxprofit = u1.profit;
				includedLevels = new ArrayList<Integer>(u1.getIncludedLevels());
			}

			if (bound(u1) > maxprofit) {
				queue.add(u1); // prepare for one more node visit
			}

			Node u2 = new Node();
			u2.level = v1.level + 1;
			u2.weight = v1.weight; // Set u2 to a child of v
			u2.profit = v1.profit; // Set u2 to the child that does not include the next item.

			u2.setIncludedLevels(v1.getIncludedLevels());
			if (bound(u2) > maxprofit) {
				queue.add(u2); // prepare for one more node visit
			}
		}
	}

	public static float bound(Node u) {
		int j, k;
		int totalweight;
		float result;
		if (u.weight >= W) {
			return 0;
		} else {
			result = u.profit;
			j = u.level + 1;
			totalweight = u.getWeight();

			while (j < n && totalweight + w[j] <= W) {
				totalweight = totalweight + w[j]; // Grab as many items as possible.
				result = result + p[j];
				j++;
			}

			k = j;
			if (k < n) {
				float pk = p[k];
				float wk = w[k];
				float x = pk / wk;
				result = result + (W - totalweight) * x;
			}
			return result; // Grab fraction of the kth item.
		}
	}

	public static void resetTestConditions(int newW, int[] newProfits, int[] newWeights) {
		includedLevels = new ArrayList<Integer>();
		W = newW;
		maxprofit = 0;
		p = newProfits;
		w = newWeights;
	}

	public static void printSolution() {
		System.out.println("There was a total profit of: " + maxprofit);
		String selectedItems = "";

		for (int i = 0; i < includedLevels.size(); i++) {
			selectedItems = selectedItems + " " + (includedLevels.get(i) + 1);
		}

		System.out.println("The items selected were: " + selectedItems);
		System.out.println("Number of node visits: " + count);
		System.out.println();
	}

	private static void executeTest(int newW, int[] newProfits, int[] newWeights) {
		resetTestConditions(newW, newProfits, newWeights);
		knapsack2();
		printSolution();
	}

	public static void main(String[] args) {

		System.out.println("Starting test on knapsack2...\n");
		executeTest(16, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(18, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(25, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(40, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(1, new int[] { 1, 1, 1, 1 }, new int[] { 2, 3, 4, 5 });
		System.out.println("Program execution finished.");
	}
}