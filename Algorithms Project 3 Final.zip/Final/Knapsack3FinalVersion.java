
/***************************************************************************/
/*                                                                         */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	           */
/*	   Assignment/Program: Project 3/Knapsack3FinalVersion			       */
/*	   Description: Solve the knapsack 0-1 problem using algorithm 6.2	   */
/*	   Author: Ricky Botelho							  			       */
/* 	   Modified: 05/17/2022	 	                                           */
/*                                                              	       */
/***************************************************************************/

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Knapsack3FinalVersion {

	static int n = 4;
	static int[] p;
	static int[] w;
	static int W;
	static int maxProfit;
	static int nodeCount;
	static List<Integer> resultLevels;

	static class Node implements Comparable<Node> {
		List<Integer> includedLevels = new ArrayList<Integer>();
		int level;
		int profit;
		int weight;
		float bound;

		/*
		 * Comparable method that orders elements with higher bound to be before those
		 * with lower bound
		 */

		public int compareTo(Node node) {
			if (bound < node.bound) {
				return 1;
			} else if (bound > node.bound) {
				return -1;
			} else {
				return 0;
			}
		}

		public void setIncludedLevels(List<Integer> value) {
			includedLevels.addAll(value);
		}

		public List<Integer> getIncludedLevels() {
			return includedLevels;
		}

		public void appendLevel(Integer level) {
			includedLevels.add(level);
		}
	}

	/*
	 * Algorithm 6.2 - The Best-First Search with Branch-and-Bound Pruning Algorithm
	 * for the 0-1 Knapsack problem
	 */
	static void knapsack3() {

		PriorityQueue<Node> pq = new PriorityQueue<>();// create priority queue
		Node v = new Node();
		pq.clear();// initialize priority queue

		v.level = -1; // initialize v as the root
		v.profit = 0;
		v.weight = 0;
		maxProfit = 0;

		v.bound = bound(v);
		pq.offer(v);

		while (!pq.isEmpty()) {
			nodeCount++;
			v = pq.poll();
			if (v.bound > maxProfit) {
				Node u = new Node();

				u.level = v.level + 1;
				u.weight = v.weight + w[u.level];
				u.profit = v.profit + p[u.level];

				u.setIncludedLevels(v.getIncludedLevels());
				u.appendLevel(u.level);

				if (u.weight <= W && u.profit > maxProfit) {
					maxProfit = u.profit;
					resultLevels = new ArrayList<Integer>(u.getIncludedLevels());
				}

				u.bound = bound(u);
				if (u.bound > maxProfit) {
					pq.offer(u);
				}

				Node u2 = new Node();
				u2.level = v.level + 1;
				u2.weight = v.weight;
				u2.profit = v.profit;
				u2.bound = bound(u2);

				u2.setIncludedLevels(v.getIncludedLevels());
				if (u2.bound > maxProfit) {
					pq.offer(u2);
				}
			}
		}
	}

	public static float bound(Node u) {
		int j, k;
		int totalweight;
		float result;
		if (u.weight >= W) {
			return 0;
		} else {
			result = u.profit;
			j = u.level + 1;
			totalweight = u.weight;

			while (j < n && totalweight + w[j] <= W) {
				totalweight = totalweight + w[j]; // Grab as many items as possible.
				result = result + p[j];
				j++;
			}

			k = j;
			if (k < n) {
				float pk = p[k];
				float wk = w[k];
				float x = pk / wk;
				result = result + (W - totalweight) * x;
			}
			return result; // Grab fraction of the kth item.
		}
	}

	public static void resetTestConditions(int newW, int[] newProfits, int[] newWeights) {
		resultLevels = new ArrayList<Integer>();
		W = newW;
		maxProfit = 0;
		p = newProfits;
		w = newWeights;
	}

	public static void printSolution() {
		System.out.println("There was a total profit of: " + maxProfit);
		String selectedItems = "";

		for (int i = 0; i < resultLevels.size(); i++) {
			selectedItems = selectedItems + " " + (resultLevels.get(i) + 1);
		}

		System.out.println("The items selected were: " + selectedItems);
		System.out.println("Number of node visits: " + nodeCount);
		System.out.println();
	}

	private static void executeTest(int newW, int[] newProfits, int[] newWeights) {
		resetTestConditions(newW, newProfits, newWeights);
		knapsack3();
		printSolution();
	}

	public static void main(String[] args) {

		System.out.println("Starting test on knapsack3...\n");
		executeTest(16, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(18, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(25, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(40, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(1, new int[] { 1, 1, 1, 1 }, new int[] { 2, 3, 4, 5 });
		System.out.println("Program execution finished.");
	}
}