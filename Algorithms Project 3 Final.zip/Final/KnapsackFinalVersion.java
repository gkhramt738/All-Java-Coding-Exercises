
/***************************************************************************/
/*                                                                    	   */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	      	   */
/*	   Assignment/Program: Project 3/KnapsackFinalVersion 			  	   */
/*	   Description: Solve the knapsack 0-1 problem using algorithm 5.7	   */
/*	   Author: George Khramtchenko									  	   */
/* 	   Modified: 05/17/2022	 	                                      	   */
/*                                                              	  	   */
/***************************************************************************/

public class KnapsackFinalVersion {

	private static int W = 0;
	static int maxprofit;
	private static int n = 4;
	static int weights[];
	static int profits[];


	static boolean bestset[] = new boolean[n];
	static boolean include[] = new boolean[n];
	static int iterationCount = 0;

	// Algorithm 5.7 - The Backtracking Algorithm for the 0-1 Knapsack problem
	public static void knapsack(int iteration, int profit, int weight) {

		iterationCount++;
		if (weight <= W && profit > maxprofit) {
			maxprofit = profit;

			for (int l = 0; l < n; l++) {
				bestset[l] = include[l];
			}
		}

		if (promising(iteration, profit, weight)) {
			include[iteration + 1] = true; // include
			knapsack(iteration + 1, profit + profits[iteration + 1], weight + weights[iteration + 1]);
			include[iteration + 1] = false; // don't include
			knapsack(iteration + 1, profit, weight);
		}
	}

	static boolean promising(int iteration, int profit, int weight) {
		int j, k, totalWeight;
		float bound;

		if (weight >= W) {
			return false;
		} else {
			j = iteration + 1;
			bound = profit;
			totalWeight = weight;

			while (j < n && totalWeight + weights[j] <= W) {
				totalWeight = totalWeight + weights[j];
				bound = bound + profits[j];
				j++;
			}

			k = j;
			if (k < n) {
				float p = profits[k];
				float w = weights[k];
				bound = bound + ((W - totalWeight) * (p / w));
			}

			return bound > maxprofit;
		}
	}

	public static void resetTestConditions(int newW, int[] newProfits, int[] newWeights) {
		W = newW;
		iterationCount = 0;
		bestset = new boolean[n];
		maxprofit = 0;
		profits = newProfits;
		weights = newWeights;
	}

	public static void printSolution() {
		System.out.println("There was a total profit of: " + maxprofit);
		String selectedItems = "";

		for (int i = 0; i < n; i++) {
			if (bestset[i] == true) {
				selectedItems = selectedItems + " " + (i + 1);
			}
		}

		System.out.println("The items selected were: " + selectedItems);
		System.out.println("Number of node visits: " + iterationCount);
		System.out.println();
	}

	private static void executeTest(int newW, int[] newProfits, int[] newWeights) {
		resetTestConditions(newW, newProfits, newWeights);
		knapsack(-1, 0, 0);
		printSolution();
	}

	public static void main(String[] args) {

		System.out.println("Starting test on knapsack...\n");
		executeTest(16, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(18, new int[] { 40, 30, 50, 10 }, new int[] { 2, 5, 10, 5 });
		executeTest(25, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(40, new int[] { 50, 55, 15, 50 }, new int[] { 2, 10, 5, 20 });
		executeTest(1, new int[] { 1, 1, 1, 1 }, new int[] { 2, 3, 4, 5 });
		System.out.println("Program execution finished.");
	}
}