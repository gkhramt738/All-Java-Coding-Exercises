
/***************************************************************************/
/*                                                                     	   */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	       	   */
/*	   Assignment/Program: Project 3/Node								   */
/*	   Description: Solve the knapsack 0-1 problem using algorithm 6.1	   */
/*	   Author: Sarita Poudyal Bhandari								   	   */
/* 	   Modified: 05/17/2022	 	                                       	   */
/*                                                              	   	   */
/***************************************************************************/

import java.util.ArrayList;
import java.util.List;

public class Node {

	List<Integer> includedLevels = new ArrayList<Integer>();
	int value;
	int profit;
	int level;
	int weight;

	public Node() {
		level = 0;
		weight = 0;
	}

	public Node(int value) {
		this.value = value;
		level++;
	}

	public int getProfit() {
		return profit;
	}

	public void setProfit(int value) {
		profit = value;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int value) {
		this.weight = value;
	}

	public int getsetLevel() {
		return level;
	}

	public void setLevel(int value) {
		level = value;
	}

	public void setIncludedLevels(List<Integer> value) {
		includedLevels.addAll(value);
	}

	public List<Integer> getIncludedLevels() {
		return includedLevels;
	}

	public void appendLevel(Integer level) {
		includedLevels.add(level);
	}
}