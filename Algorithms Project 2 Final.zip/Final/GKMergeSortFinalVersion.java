
/***********************************************************************/
/*                                                                     */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	       */
/*	   Project/Program: Project 2/GKMergeSortFinalVersion 	           */
/*	   Description: Perform mergesort algorithm on 9 .txt int files	   */
/*	   Author: George Khramtchenko									   */
/* 	   Modified: 04/07/2022	 	                                       */
/*                                                              	   */
/***********************************************************************/

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GKMergeSortFinalVersion {

	static int basicOperationsCount = 0;

	// Problem: Sort n keys in nondecreasing sequence.
	// Input: positive integer n, array of keys S indexed from 1 to n.
	// Outputs: the array S containing the keys in nondecreasing order.

	public static void mergesort(int n, int S[]) {
		if (n > 1) {
			basicOperationsCount++;
			int mid = (n / 2);
			int m = (n - mid);
			int U[] = new int[mid];
			int V[] = new int[m];
			// keytype U[1..h], V[1..m];

			basicOperationsCount++; // basic ops count before for loop
			// Copy S[1] through S[h] to U[1] through U[h];
			for (int i = 0; i < mid; i++) {
				U[i] = S[i]; // Copy S to U - first half
			}

			basicOperationsCount++; // basic ops count before for loop
			// Copy S[h+1] through S[n] to V[1] through V[m];
			for (int i = mid; i < n; i++) {
				V[i - mid] = S[i]; // Copy S to U - second half
			}

			mergesort(mid, U);
			mergesort(m, V);
			merge(mid, m, U, V, S);
		}
	}

	/*
	 * Problem: Merge two sorted arrays into one sorted array. Input: Positive
	 * integers h and m, array of sorted keys U indexed from 1 to h array of sorted
	 * keys V indexed from 1 to m. Outputs: an array S indexed from 1 to h + m
	 * containing the keys in U and V in a // single sorted array.
	 */

	public static void merge(int h, int m, int U[], int V[], int S[]) {
		int i, j, k;

		i = 0;
		j = 0;
		k = 0;

		basicOperationsCount++; // basic ops count before while loop
		while (i < h && j < m) {
			if (U[i] < V[j]) { // sort left array
				S[k] = U[i];
				i++;
			} else {
				S[k] = V[j]; // sort right array
				j++;
			}
			k++;
		}

		basicOperationsCount++; // basic ops count before for loop
		if (i >= h) {
			// Copy V[j] through V[m] to S[k] through S[h+m]
			for (int l = j; l < m; l++) {
				S[k] = V[l];
				k++;
			}
		} else {
			basicOperationsCount++; // basic ops count before for loop
			// Copy V[i] through U[h] to S[k] through S[h+m];
			for (int l = i; l < h; l++) {
				S[k] = U[l];
				k++;
			}
		}
	}

	public static void main(String[] args) throws IOException {

		// Create an array of strings to store all files
		String[] fileNames;

		File f = new File("src/");
		// f.list updates string array with names of files
		fileNames = f.list();
		
		basicOperationsCount++; // basic ops count before for loop
		// specifies what happens to each fileName in the array fileNames
		for (String fileName : fileNames) {
			// Get file
			File file = new File("src/" + fileName);

			// This part makes sure that non .txt files are not used for the sorting
			// algorithms sort times
			if (!file.getName().endsWith(".txt")) {
				continue;
			}

			Scanner scanner = new Scanner(file);
			// List Integer will be used to store .txt file numbers
			List<Integer> originalArray = new ArrayList<>();

			while (scanner.hasNext()) {
				if (scanner.hasNextInt()) {
					originalArray.add(scanner.nextInt());
				} else {
					scanner.next();
				}
			}
			scanner.close();

			// Take the List<Integer> originalArray and assign to arrToSort[]
			int arrToSort[] = new int[originalArray.size()];
			// Convert originalArray to arrToSort
			for (int i = 0; i < originalArray.size(); i++)
				arrToSort[i] = originalArray.get(i);

			long stime = System.nanoTime(); // Algorithm start time
			mergesort(arrToSort.length, arrToSort);
			long etime = System.nanoTime(); // Algorithm end time

			// Total merge sort algorithm runtime 
			long totalTime = etime - stime;
			System.out.println("Algorithm mergesort sum runtime for " + fileName + " is " + (totalTime) + "ns.");
			System.out.println("Basic operations for file " + fileName + " using mergesort() is " + (basicOperationsCount) + " basic operations.\n");
		}
		System.out.println("Program execution completed.");
	}
}