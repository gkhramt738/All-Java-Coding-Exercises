
/***********************************************************************************/
/*                                                                     	       	   */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	       	      	   */
/*	   Project/Program: Project 2/MKInsertionSortFinalVersion	               	   */
/*	   Description: Perform array insertion sort algorithm on 9 .txt int files	   */
/*	   Author: Maeve Kenny										       		   	   */
/* 	   Modified: 04/07/2022	                                    	       	   	   */
/*                                                              	   	       	   */
/***********************************************************************************/

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MKInsertionSortFinalVersion {

	static int basicOperationsCount = 0;

	public static void insertionSort(int arr[]) {
		// loop searches for target then moves right scanning/shifting next elements in
		// array

		basicOperationsCount++; // basic ops count before for loop
		for (int i = 1; i < arr.length; i++) {
			int target = arr[i];
			// x is loop variable that references the moving item in array
			int x = i - 1;

			basicOperationsCount++; // basic ops count before while loop
			// while loop deals with sorting items whether x is greater than 0 and target
			while (x >= 0 && target < arr[x]) {
				// copies item of array x to the right
				arr[x + 1] = arr[x];
				// decrements x
				x--;
			}

			basicOperationsCount++; // basic ops count after while loop
			// set target to just after the element smaller than itself
			arr[x + 1] = target;
		}
	}

	public static void main(String args[]) throws IOException {

		// creates array of strings called fileNames that stores the txt files
		String[] fileNames;
		File f = new File("src/");
		// f.list updates string array with names of files
		fileNames = f.list();

		basicOperationsCount++; // basic ops count before for loop
		// specifies what happens to each fileName in the array fileNames
		for (String fileName : fileNames) {
			// get file, specify path
			File file = new File("src/" + fileName);

			// specifies that non .txt files should not be accounted for when sorting
			if (!file.getName().endsWith(".txt")) {
				continue;
			}

			Scanner sc = new Scanner(file);
			// List<Integer> stores the .txt file numbers
			List<Integer> ogArray = new ArrayList<>();
			// while loop deals with scanning ogArray
			while (sc.hasNext()) {
				if (sc.hasNextInt()) {
					ogArray.add(sc.nextInt());
				} else {
					sc.next();
				}
			}
			sc.close();

			// List<Integer> ogArray is assigned to arrToSort[]
			int newArray[] = new int[ogArray.size()];
			// convert ogArray to newArray
			for (int i = 0; i < ogArray.size(); i++) {
				newArray[i] = ogArray.get(i);
			}

			long stime = System.nanoTime(); // algorithm start timer
			insertionSort(newArray);
			long etime = System.nanoTime(); // algorithm end timer

			// check if array sorted
			for (int i = 1; i < newArray.length; i++) {
				// print error message if unsorted
				if (newArray[i] < newArray[i - 1]) {
					System.out.println("ERROR: array unsorted");
				}
			}

			// total insertion sort algorithm runtime
			long totalTime = etime - stime;
			System.out.println("Insertion sort algorithm runtime for " + fileName + " is " + (totalTime) + "ns.");
			System.out.println("Basic operations for file " + fileName + " using insertionSort() is " + (basicOperationsCount) + " basic operations.\n");
		}
		System.out.println("Program execution completed.");
	}
}