
/*******************************************************************************************/
/*                                                                     	       	   	       */
/*     Course: COMSC.340.01-22/SP Analysis of Algorithms       	       	      	   	       */
/*	   Project/Program: Project 2/MKLinkedListISortFinalVersion	               	   	       */
/*	   Description: Perform linked list insertion sort algorithm on 9 .txt int files	   */
/*	   Author: Maeve Kenny										       		   	   	   	   */
/* 	   Modified: 04/07/2022	                                    	       	   	   	   	   */
/*                                                              	   	       	   	   	   */
/*******************************************************************************************/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MKLinkedListISortFinalVersion {

	static int basicOperationsCount = 0;
	// head and tail sorted first in linked list, in this case tail is the sorted
	// list
	node head;
	node sorted;

	class node {
		int data;
		node n;

		// int declared given list as data
		public node(int data) {
			this.data = data;
		}
	}

	public void push(int data) {
		basicOperationsCount++;
		// declares newNode to head
		node newNode = new node(data);
		newNode.n = head;
		// moves head to point to newNode
		head = newNode;
	}

	// insertion algorithm implemented here
	public void insertionSort(node headref) {
		sorted = null;
		node current = headref;

		basicOperationsCount++; // basic ops count before while loop
		// searches within given list to insert every node to sorted list
		while (current != null) {
			// stores n for next iteration
			node n = current.n;
			// inserts current into revised list
			sortedI(current);
			// updates current
			current = n;
		}
		// updates head to revised list
		head = sorted;
	}

	// function to insert a newNode in list
	public void sortedI(node newNode) {

		basicOperationsCount++; // basic ops count before if stmt
		// special case for the head end
		if (sorted == null || sorted.data >= newNode.data) {
			newNode.n = sorted;
			sorted = newNode;
		}

		else {
			basicOperationsCount++;
			node current = sorted;
			basicOperationsCount++; // basic ops count before while loop

			// locates node before point of insertion
			while (current.n != null && current.n.data < newNode.data) {
				current = current.n;
			}

			newNode.n = current.n;
			current.n = newNode;
		}
	}

	// function prints linked list
	public void printLL(node head) {
		basicOperationsCount++; // basic ops count before while loop
		while (head != null) {
			System.out.print(head.data + " ");
			head = head.n;
		}
	}

	public static void main(String[] args) throws FileNotFoundException {

		// Create an array of strings to store all files
		String[] fileNames;

		File f = new File("src/");
		// f.list updates string array with names of files
		fileNames = f.list();

		basicOperationsCount++; // basic ops count before for loop
		// specifies what happens to each fileName in the array fileNames
		for (String fileName : fileNames) {
			// Get file, specify path
			File file = new File("src/" + fileName);

			// Create a newList of LinkedListISortV3 class
			MKLinkedListISortFinalVersion newList = new MKLinkedListISortFinalVersion();
			Scanner scanner = new Scanner(new FileInputStream(file));

			// This part makes sure non .txt files are not used for sorting algorithms sort
			// times
			if (!file.getName().endsWith(".txt")) {
				continue;
			}

			while (scanner.hasNext()) {
				if (scanner.hasNextInt()) {
					// convert the next int that is scanned into a string
					String readLine = scanner.nextLine().trim(); // .trim() ignores spaces that may be between ints
					// pushes the line just read onto newList LL (changed to .push from .add)
					newList.push(Integer.parseInt(readLine)); // Integer.parseInt() parses string argument as an int
				} else {
					scanner.next();
				}
			}
			scanner.close();

			long stime = System.nanoTime(); // start timer
			newList.insertionSort(newList.head);
			long etime = System.nanoTime(); // end timer

			// total linked list insertion sort algorithm runtime
			long totalTime = etime - stime;
			System.out.println("Linked List Insertion sort algorithm runtime for " + fileName + " is " + (totalTime) + "ns.");
			System.out.println("Basic operations for file " + fileName + " using insertionSort() linked list is " + (basicOperationsCount) + " basic operations.\n");
		}
		System.out.println("Program execution completed.");
	}
}